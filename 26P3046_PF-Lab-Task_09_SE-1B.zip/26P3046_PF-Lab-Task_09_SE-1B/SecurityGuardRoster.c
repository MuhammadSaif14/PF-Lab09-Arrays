#include<stdio.h>
int main()
{
	int i,k,guard[7],newRoster[7],id,day=-1;
	
	printf("Enter guard IDs for Day 1 to Day 7: \n");
	
	for(i=0;i<7;i++)
	{
		printf("Day %d: ", i+1);
		scanf("%d", &guard[i]);
	}
	
	printf("Shift roster forward by how many days (1-6)? : ");
	scanf("%d", &k);
	
	for(i=0;i<7;i++)
	{
		newRoster[(i+k)%7] = guard[i];
	}
	printf("\nDay\tOld\tNew\n");
	
	for(i=0;i<7;i++)
	{
		printf("Day %d\t%d\t%d\n", i+1, guard[i], newRoster[i]);
	}
	
	printf("\n Enter your Guard id: ");
	scanf("%d", &id);
	
	for(i=0;i<7;i++)
	{
		if(newRoster[i] == id)
		{
			day = i+1;
			break;
		}
	}
	
	if(day != -1)
		printf("Guard %d now has duty on day %d.", id,day);
	else
		printf("Guard ID not found.");
	
	return 0;
}
