#include<stdio.h>
int main()
{
	int i,j,ticket[7],forged=0,genuine=0,found;
	
	for(i=0;i<7;i++)
	{
		printf("Ticket of person %d: ",i+1);
		scanf("%d", &ticket[i]);
	}
	printf("\n--- GATE REPORT ---\n");
	
	for(i=0;i<7;i++)
	{
		found = 0;
		
		for(j=0;j<i;j++)
		{
			if(ticket[i] == ticket[j])
			{
				printf("FORGED: person %d used ticket %d, already used by person %d\n", i+1,ticket[i],j+1);
				forged++;
				found = 1;
				break;
			}
		}
		
		if(found==0)
		{
			genuine++;
		}
	}
	
	printf("Genuine: %d, Forged: %d\n",genuine,forged);
	 
	
	
	return 0;
}
