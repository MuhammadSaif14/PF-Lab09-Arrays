#include<stdio.h>
int main()
{
	int i, judge=-1;
	float score[7], sum = 0, highest, lowest, final_score; 
	
	for(i=0;i<7;i++)
	{
		printf("Judge %d score: ", i+1);
		scanf("%f", &score[i]);
	}	
		
	highest = score[0];
	lowest = score[0];
	
	// Starting low at 0 is wrong because all scores are positive,
    // so 0 would remain the lowest even though no judge gave 0.
	
	for(i=0;i<7;i++)
	{
		sum = sum + score[i];
		
		if(score[i] > highest)
		{
			highest = score[i];
		}
		
		if(score[i] < lowest)
		{
			lowest = score[i];
		}
	} 
	final_score = (sum-highest-lowest)/5;
	
	printf("\n");
	printf("Highest score dropped: %.1f \n", highest);
	printf("Lowest score dropped: %.1f \n", lowest);
	printf("Final score: %.2f \n", final_score);
	
	for(i=0;i<7;i++)
	{
		if(score[i] == 10)
		{
			judge = i+1;
			break;
		}
		
	}
	
	if(judge != -1)
		printf("Judge %d gave a perfect 10!", judge);
	else
		printf("No judge gave a perfect 10.\n");
	
	return 0;
}
