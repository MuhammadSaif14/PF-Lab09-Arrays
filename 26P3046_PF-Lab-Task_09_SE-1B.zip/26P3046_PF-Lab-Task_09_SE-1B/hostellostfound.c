#include<stdio.h>
int main()
{
	int i, locker[10], count=1, item_code, total_lockers=0, empty_lockers=0, locker_n=1;
	
	printf("Enter item code in each locker (0 = empty): \n");
	
	for(i=0;i<10;i++)
	{
		printf("Locker %d: ", count);
		scanf("%d", &locker[i]);
		
		count++;
	}
	printf("Enter item code to search: ");
	scanf("%d", &item_code);

	
	for(i=0;i<10;i++)
	{
		if(item_code == locker[i])
		{
			printf("Item %d is in locker %d \n", item_code, locker_n);
			total_lockers++;
		}
		if(locker[i]==0)
		{
			empty_lockers++;
		}
		locker_n++;
	}
	if(total_lockers == 0)
		printf("Item %d is not in any locker.\n", item_code);
	else
		printf("Total lockers with this item: %d \n", total_lockers);
	
		printf("Empty lockers: %d", empty_lockers);
	
	
	
	
	

	
	
	
	
	return 0;
}
