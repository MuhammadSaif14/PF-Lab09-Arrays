#include<stdio.h>
int main()
{
	int i, runs[6], count=1, total_runs, best=0, runs_needed, over=0;
	float  run_rate;
	
	for(i=0;i<6;i++)
	{
		printf("Runs in over %d: ", count);
		scanf("%d", &runs[i]);
		
		total_runs = total_runs + runs[i];
		run_rate = total_runs/6;
		
		if(runs[i] > best)
		{
			best = runs[i];
			over = count;
		}
		
		if(total_runs < 60)
		{
			runs_needed = 60 - total_runs;
		}
		
		count++;
	}
	printf("\n");
	printf("Total runs: %d \n", total_runs);
	printf("Run rate: %.2f per over \n", run_rate);
	printf("Best over: Over %d with %d runs \n", over, best);
	if(total_runs < 60)
		printf("Needed %d runs to reach 60.", runs_needed);
	
	return 0;
}
